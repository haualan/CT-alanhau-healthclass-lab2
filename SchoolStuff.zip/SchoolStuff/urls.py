from django.conf.urls import patterns, url

from RAscore import views

urlpatterns = patterns('',
  # url(r'^$', views.IndexView.as_view(), name='index'),
  url(r'^docScore/$', views.docScoreView.as_view(), name='docScore'),
#   url(r'^(?P<pk>\d+)/$', views.DetailView.as_view(), name='detail'),
#   url(r'^(?P<pk>\d+)/results/$', views.ResultsView.as_view(), name='results'),
#   url(r'^(?P<question_id>\d+)/vote/$', views.vote, name='vote'),
#   url(r'^init_google_login/$', views.init_google_login, name='init_google_login'),
  
# )