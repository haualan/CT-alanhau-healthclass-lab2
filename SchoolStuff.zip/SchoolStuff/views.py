from django.shortcuts import render, get_object_or_404
from django.core.urlresolvers import reverse
from django.http import HttpResponseRedirect
from django.views import generic
from django.utils import timezone
from vanilla import CreateView, ListView
import ohmageData, FatBitAPI, plotGraph, NLPModel

# Create your views here.
from RAscore.models import Question, Choice



# def index(request):
#   latest_question_list = Question.objects.order_by('-pub_date')[:5]
#   context = {'latest_question_list': latest_question_list}
#   return render(request, 'RAscore/index.html', context)


# def detail(request, question_id):
#   question = get_object_or_404(Question, pk=question_id)
#   return render(request, 'RAscore/detail.html', {'question': question})

# def results(request, question_id):
#   question = get_object_or_404(Question, pk=question_id)
#   return render(request, 'RAscore/results.html', {'question': question})


# class IndexView(ListView):
class IndexView(generic.ListView):
    template_name = 'RAscore/index.html'
    context_object_name = 'latest_question_list'

    def get_queryset(self):
      """
      Return the last five published questions (not including those set to be
      published in the future).
      """
      return Question.objects.filter(
          pub_date__lte=timezone.now()
      ).order_by('-pub_date')[:5]






class DetailView(generic.DetailView):
    model = Question
    template_name = 'RAscore/detail.html'

    def get_queryset(self):
      """
      Excludes any questions that aren't published yet.
      """
      return Question.objects.filter(pub_date__lte=timezone.now())


class ResultsView(generic.DetailView):
    model = Question
    template_name = 'RAscore/results.html'


class docScoreView(generic.View):

  def get(self, request):
    # a = NLPModel.NLPModel()
    # r = a.useModel("testString a husband RA Rheumatoid Arthritis")
    # return render_to_response('patient/dashboard.html', context_instance = RequestContext(request))
    return render(request,'RAscore/docScore.html', 
      {"get": True} 
      )

  def post(self, request):
    textEntry = request.POST['textEntry']

    a = NLPModel.NLPModel()
    r = a.useModel(textEntry)
    comments = [
    "Your score is below 25, Your writing is truly unhelpful at all or off-topic, please rewrite your content and try again.",
    "Your score is below 50, patients would generally find your text uninteresting or not helpful, look at the tips above and study the examples and edit your content. Don't give up!",
    "Your score is above 50, patients would generally find your text interesting and helpful. Incorporate more attributes from our tips section to see if you can score even higher.",
    "Your score is above 75, you have done a great job to make your writing interesting for your patients. Well done!"

    ]

    score = (((r + 10) / 20 ) * 100)

    if score < 25:
      if score < 0:
        score = 0
      comment = comments[0]
    elif score >= 25 and score < 50:
      comment = comments[1]
    elif score >= 50 and score < 75:
      comment = comments[2]
    elif score >= 75:
      if score > 100:
        score = 100
      comment = comments[3]



    return render(request,'RAscore/docScore.html', 
      {
        "relativeScore": "{:.0f}".format(score),
        "textEntry": textEntry,
        "comment": comment
      }  
      )


def vote(request, question_id):
  p = get_object_or_404(Question, pk=question_id)
  try:
      selected_choice = p.choice_set.get(pk=request.POST['choice'])
  except (KeyError, Choice.DoesNotExist):
      # Redisplay the question voting form.
      return render(request, 'RAscore/detail.html', {
          'question': p,
          'error_message': "You didn't select a choice.",
      })
  else:
      selected_choice.votes += 1
      selected_choice.save()
      # Always return an HttpResponseRedirect after successfully dealing
      # with POST data. This prevents data from being posted twice if a
      # user hits the Back button.
      return HttpResponseRedirect(reverse('RAscore:results', args=(p.id,)))

def init_google_login(request):
  """
  logs in via google oauth
  """
  a = ohmageData.ohmageDataClass()
  url = a.login()
  return HttpResponseRedirect(url)

def callback(request):
  """
  after google login, a code/token is generated, use this to refresh token
  """
  code = request.GET.get('code', '')
  state = request.GET.get('state', '')

  a = ohmageData.ohmageDataClass()
  a.getAccessToken(code)

  # gather data
  fitBitTS = FatBitAPI.getFloorsTimeSeries()
  a.parse_mobility_daily_summary(a.getDataPoints(schema_namespace = 'cornell', schema_name = 'mobility-daily-summary'))
  a.parse_pam(a.getDataPoints(schema_namespace = 'omh', schema_name = 'pam'))
  isDepressed = a.isDepressed()
  
  # graphdata
  graphUrl = plotGraph.plotGraph(fitbitTS = fitBitTS, pam_data = a.pam, mobility_data = a.mobility)

  # return HttpResponseRedirect(reverse('RAscore:index'))
  return render(request,'RAscore/index.html', 
      {"pam_data": a.pam,
        "mobility_data": a.mobility,
        "isDepressed": isDepressed
        } 
      )



