# -*- coding: utf-8 -*-
import os
import sys
import requests, json, base64, pickle, time
from requests_oauthlib import OAuth2, OAuth1
from requests_oauthlib import OAuth2Session, OAuth1Session
from splinter import Browser
from pprint import pprint
import numpy as np

BASE_DIR = os.path.dirname(__file__)
base_url = 'https://ohmage-omh.smalldata.io/dsu'
client_id = '5555-2015-alan'
client_secret = 'Rtg43jkLD7z76c'
redirect_uri = 'http://localhost:7777/callback'
# redirect_uri = 'http://www.google.com'
# token = 'y4auuD'

b64Val = 'Basic ' + base64.b64encode('{}:{}'.format(client_id, client_secret))
auth_headers = {'Authorization': b64Val}

class ohmageDataClass:
  """docstring for ohm"""
  def __init__(self):
    self.arg = 'arg'
    self.tokens = pickle.load( open( BASE_DIR +'/user_tokens.p', "rb" ) )
    # self.renewIfNecessary()


  def login(self, open_browser = False):
    # request_token_url = 'https://ohmage-omh.smalldata.io/dsu/oauth/authorize?client_id={}&response_type=code'.format(client_key)
    
    # client_id = '48636836762-mulldgpmet2r4s3f16s931ea9crcc64m.apps.googleusercontent.com'
    # base_url = 'https://lifestreams.smalldata.io/dsu'

    request_token_url = base_url +'/oauth/authorize?client_id={}&response_type=code'.format(client_id)
    print request_token_url

    oauth = OAuth2Session(client_id)
    authorization_url, state = oauth.authorization_url(request_token_url)
    print authorization_url, state

    if open_browser:
      browser = Browser()
      browser.visit(authorization_url)
      token = raw_input('enter code from google sign in:')
      return token
    else:
      return authorization_url

    

    # oauth = OAuth2Session(client_id, scope = scope, redirect_uri = redirect_uri)
    # authorization_url, state = oauth.authorization_url(request_token_url,
    # # offline for refresh token
    # # force to always make user click authorize
    # access_type="offline", approval_prompt="force")
    # print 'Please go here and authorize,', authorization_url
  def getAccessToken(self, code):
    request_token_url = base_url + '/oauth/token'

    payload = {'code': code, 'grant_type': 'authorization_code'}
    r = requests.post(url=request_token_url, params = payload, headers = auth_headers)
    r = json.loads(r.text.encode('ascii', 'ignore'))

    pickle.dump( r, open( BASE_DIR + '/user_tokens.p', "wb" ) )

    return r

  def checkToken(self):
    print self.tokens
    checkToken_url = base_url + '/oauth/check_token?token={}'.format(self.tokens['access_token'])
    r = requests.get(url= checkToken_url)
    r = json.loads(r.text.encode('ascii', 'ignore'))
    # print r
    return r

  def renewToken(self):
    renewToken_url = base_url + '/oauth/token'
    payload = {'refresh_token': self.tokens['refresh_token'], 'grant_type': 'refresh_token'}
    r = requests.post(url=renewToken_url, params = payload, headers = auth_headers)
    r = json.loads(r.text.encode('ascii', 'ignore'))

    pickle.dump( r, open( BASE_DIR + '/user_tokens.p', "wb" ) )

    self.tokens = r

    # print r

  def renewIfNecessary(self):
    try:
      # Checks if token is expired and renews user tokens if so.
      r = self.checkToken()
      # epoch_time = int(time.time())
      if 'error' in r:
        print 'token expired... renewing'
        self.renewToken()
    except:
      print 'error encountered renewing token...'
      self.renewToken()

  def getDataPoints(self, schema_namespace, schema_name,fromDate = None , toDate = None, schema_version = '1.0' ):
    self.renewIfNecessary()
    url = base_url + '/dataPoints'
    payload = {
      'schema_namespace':schema_namespace,
      'schema_name':schema_name,
      'schema_version':schema_version,
      }

    if not(fromDate is None):
      payload['created_on_or_after'] = fromDate

    if not(toDate is None):
      payload['created_before'] = toDate


    # print payload

    
    headers = {'Authorization': 'Bearer {}'.format(self.tokens['access_token'])}
    # print headers
    r = requests.get(url = url, headers = headers, params = payload)
    # print r
    try:
      r = json.loads(r.text.encode('ascii', 'ignore'))
      # print r
    except:
      print 'some error has occured'
      # print r

    return r

  def parse_pam(self, iData):
    """
    takes pam data input from omh and parses them to data for plot generation

    """


    # print len(iData)
    negative_affect = []
    positive_affect = []
    pam_datetimes = []

    for i in iData:
      negative_affect.append(int(i['body']['negative_affect']['value']))
      positive_affect.append(int(i['body']['positive_affect']['value']))
      pam_datetimes.append(np.datetime64(i['body']['effective_time_frame']['date_time']))

    # print pam_datetimes
    r = {
      'pam_datetimes': np.array(pam_datetimes),
      'negative_affect': [np.array(negative_affect), self.getTrends(negative_affect)],
      'positive_affect': [np.array(positive_affect), self.getTrends(positive_affect)]
    }

    self.pam = r
    return r

  def parse_mobility_daily_summary(self, iData):
    mobilty_dates = []
    mobilty_walking_distance_in_km = []
    mobilty_active_time_in_seconds = []
    mobilty_max_gait_speed_in_meter_per_second = []
    mobilty_time_not_at_home_in_seconds = []
    mobilty_geodiameter_in_km  = []


    pprint(iData)


    for i in iData:
      # print i['body']['date']
      mobilty_dates.append(np.datetime64(i['body']['date']))
      try:
        mobilty_walking_distance_in_km.append(float(i['body']['walking_distance_in_km']))
      except:
        pass
      try:
        mobilty_active_time_in_seconds.append(float(i['body']['active_time_in_seconds']))
      except:
        pass
      try:
        mobilty_max_gait_speed_in_meter_per_second.append(float(i['body']['max_gait_speed_in_meter_per_second']))
      except:
        pass
      try:
        mobilty_time_not_at_home_in_seconds.append(float(i['body']['time_not_at_home_in_seconds']))
      except:
        pass
      try:
        mobilty_geodiameter_in_km.append(float(i['body']['geodiameter_in_km']))
      except:
        pass


    r = { 
      'date': np.array(mobilty_dates),
      'walking_distance_in_km': [np.array(mobilty_walking_distance_in_km), self.getTrends(mobilty_walking_distance_in_km)],
      'active_time_in_seconds': [np.array(mobilty_active_time_in_seconds), self.getTrends(mobilty_active_time_in_seconds)],
      'max_gait_speed_in_meter_per_second': [np.array(mobilty_max_gait_speed_in_meter_per_second), self.getTrends(mobilty_max_gait_speed_in_meter_per_second)],
      'time_not_at_home_in_seconds': [np.array(mobilty_time_not_at_home_in_seconds), self.getTrends(mobilty_time_not_at_home_in_seconds)],
      'geodiameter_in_km': [np.array(mobilty_geodiameter_in_km), self.getTrends(mobilty_geodiameter_in_km)]
    }

    self.mobility = r
    return r

  def getTrends(self, x):
    # average of 1d list for last n days for array x, returns the averages for 30 15 and 7 days and gives indicationi whether this is an increasing or decreasing trend
    avg_long = np.mean(x[-30:])
    avg_med = np.mean(x[-15:])
    avg_short = np.mean(x[-7:])

    if avg_long >= avg_med and avg_med >= avg_short:
      indication = 'decreasing'
    elif avg_long <= avg_med and avg_med <= avg_short:
      indication = 'increasing'
    else:
      indication = None

    return avg_long, avg_med, avg_short, indication

  def isDepressed(self):
    # according to SIG E CAPS if 5 of the 9 symptoms show unfavorable indication then raise a flag that user should seek medical health
    count = 0

    # S for Sleep Changes: too hard to check unless user inputs sleeping time into fitbit, possibly use active time as a proxy
    if self.mobility['active_time_in_seconds'][1][3] == 'increasing':
      count =+ 1

    # I for Interest: look at average geodiameter_in_km as a proxy, if it's decreasing, then it's bad
    if self.mobility['geodiameter_in_km'][1][3] == 'decreasing':
      count =+ 1

    # G for guilt: look at PAM for indication
    if self.pam['negative_affect'][1][3] == 'increasing' and self.pam['positive_affect'][1][3] == 'decreasing':
      count =+ 1

    # E for energy: look at walking distance if decreasing
    if self.mobility['walking_distance_in_km'][1][3] == 'decreasing':
      count =+ 1

    # C for Concentration / Cognition: Can't track unless we give a reaction task / game for the user depending on the other symptoms

    # A for Appetite (wt. loss); usually declined, occasionally increased, can't track unless we have a scale

    # P for Psychomotor: agitation (anxiety) or retardations (lethargic) gait speed, use Gait Speed as proxy
    if self.mobility['max_gait_speed_in_meter_per_second'][1][3] == 'decreasing':
      count =+ 1

    # S for Suicude: best if asked through a person

    if count >= 5:
      return True
    else:
      return False  






if __name__ == "__main__":
  a = ohmageDataClass()

  # token = a.login()

  # a.getAccessToken(token)
  # print a.checkToken()
  # print a.tokens

  # a.renewToken()
  # print a.getDataPoints(fromDate = '2012-09-18T14:01:54.9571247Z')

  # pprint(a.getDataPoints(schema_namespace = 'cornell', schema_name = 'mobility-daily-segments'))
  
  pprint (a.parse_mobility_daily_summary(a.getDataPoints(schema_namespace = 'cornell', schema_name = 'mobility-daily-summary')))


 
  pprint(a.parse_pam(a.getDataPoints(schema_namespace = 'omh', schema_name = 'pam')))

  print a.isDepressed()
  




