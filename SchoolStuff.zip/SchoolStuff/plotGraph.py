import plotly.plotly as py
from plotly.graph_objs import *
import FatBitAPI, ohmageData
import numpy as np

def plotGraph(fitbitTS, pam_data, mobility_data):
  # gather fitbit data
  # fitBitTS = FatBitAPI.getFloorsTimeSeries()

  dt = np.dtype([('dates', 'datetime64[D]'), ('flrs', np.int8)])
  TS = np.array(fitbitTS, dtype=dt)
  # print TS
  fb_dates = TS['dates']
  fb_flrs = TS['flrs']
  # print dates, flrs 

  # gather PAM ohmage data
  # a = ohmageData.ohmageDataClass()
  # pam_data = a.parse_pam(a.getDataPoints(schema_namespace = 'omh', schema_name = 'pam'))
  negative_affect = pam_data['negative_affect'][0]
  positive_affect = pam_data['positive_affect'][0]
  pam_datetimes = pam_data['pam_datetimes']

  # gather Mobility data from omh
  # mobility_data = a.parse_mobility_daily_summary(a.getDataPoints(schema_namespace = 'cornell', schema_name = 'mobility-daily-summary'))

  mobilty_walking_distance_in_km =  mobility_data['walking_distance_in_km'][0]
  mobilty_active_time_in_seconds = mobility_data['active_time_in_seconds'][0]
  mobilty_geodiameter_in_km = mobility_data['geodiameter_in_km'][0]
  mobilty_max_gait_speed_in_meter_per_second = mobility_data['max_gait_speed_in_meter_per_second'][0]

  mobilty_dates = mobility_data['date']


  # prep Time Series for plot
  fitBit_trace = Scatter(
      x=fb_dates,
      y=fb_flrs,
      name = 'fitBit Floors Climbed'
  )
  # data = Data([trace0])

  pam_neg_trace = Scatter(
      x=pam_datetimes,
      y=negative_affect,
      name = 'PAM negative affect'
  )

  pam_pos_trace = Scatter(
      x=pam_datetimes,
      y=positive_affect,
      name = 'PAM positive affect'
  )

  mobility_daily_walking_distance_in_km_trace = Scatter(
      x=mobilty_dates,
      y=mobilty_walking_distance_in_km,
      name = 'Mobility daily walking distance in km'
  )

  mobility_daily_active_time_in_seconds_trace = Scatter(
      x=mobilty_dates,
      y=mobilty_active_time_in_seconds,
      name = 'Mobility daily active time in seconds'
  )

  mobility_daily_geodiameter_in_km_trace = Scatter(
      x=mobilty_dates,
      y=mobilty_geodiameter_in_km,
      name = 'Mobility daily geodiameter in km'
  )

  mobility_daily_gait_speed_trace = Scatter(
      x=mobilty_dates,
      y=mobilty_max_gait_speed_in_meter_per_second,
      name = 'Mobility daily max gait speed in second'
  )



  data = Data([ fitBit_trace, 
    mobility_daily_walking_distance_in_km_trace, 
    mobility_daily_active_time_in_seconds_trace , 
    mobility_daily_geodiameter_in_km_trace,
    mobility_daily_gait_speed_trace,
    pam_neg_trace, 
    pam_pos_trace ])

  # print data

  unique_url = py.plot(data, filename = 'basic-line', auto_open=False)
  # print unique_url
  return unique_url

if __name__ == "__main__":
  
  # b = FatBitAPI.getFloorsTimeSeries()
  # print b
  url = plotGraph()